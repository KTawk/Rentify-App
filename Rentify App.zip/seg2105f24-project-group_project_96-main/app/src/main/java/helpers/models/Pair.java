package helpers.models;

public class Pair {
    public String Key;
    public String Value;


    public Pair(String key, String value) {
        this.Key = key;
        this.Value = value;
    }
}
