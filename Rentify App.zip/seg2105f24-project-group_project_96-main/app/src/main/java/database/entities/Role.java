package database.entities;

public class Role extends BaseEntity {
    public String Name;

    public Role() {

    }

    public Role(String name) {
        this.Name = name;
    }
}
