package models;

import database.entities.User;

public class UserInfo {
    public static User User;
    public static database.entities.Role Role;
}
